#include "CollapsibleBox.h"
#include <QVBoxLayout>
#include <QFrame>

CollapsibleBox::CollapsibleBox(const QString &title, QWidget *parent)
    : QWidget(parent)
{
    toggleButton = new QToolButton(this);
    contentArea = new QScrollArea(this);
    toggleAnimation = new QParallelAnimationGroup(this);

    // Configure toggle button
    toggleButton->setText(title);
    toggleButton->setCheckable(true);
    toggleButton->setChecked(false);
    toggleButton->setStyleSheet("QToolButton { border: none; }");
    toggleButton->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
    toggleButton->setArrowType(Qt::RightArrow);

    // Configure content area
    contentArea->setMaximumHeight(0);
    contentArea->setMinimumHeight(0);
    contentArea->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    contentArea->setFrameShape(QFrame::NoFrame);

    // Create main layout
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->setSpacing(0);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->addWidget(toggleButton);
    mainLayout->addWidget(contentArea);

    // Create animations
    QPropertyAnimation *animation1 = new QPropertyAnimation(this, "minimumHeight");
    QPropertyAnimation *animation2 = new QPropertyAnimation(this, "maximumHeight");
    QPropertyAnimation *animation3 = new QPropertyAnimation(contentArea, "maximumHeight");

    toggleAnimation->addAnimation(animation1);
    toggleAnimation->addAnimation(animation2);
    toggleAnimation->addAnimation(animation3);

    // Connect signals and slots
    connect(toggleButton, &QToolButton::pressed, this, &CollapsibleBox::onPressed);
}

void CollapsibleBox::onPressed()
{
    bool isChecked = toggleButton->isChecked();
    
    // Change arrow direction
    toggleButton->setArrowType(isChecked ? Qt::DownArrow : Qt::RightArrow);
    
    // Set animation direction
    toggleAnimation->setDirection(isChecked ? QAbstractAnimation::Forward : QAbstractAnimation::Backward);
    
    // Start animation
    toggleAnimation->start();
}

void CollapsibleBox::setContentLayout(QLayout *layout)
{
    // Remove existing layout from content area
    QLayout *existingLayout = contentArea->layout();
    if (existingLayout) {
        delete existingLayout;
    }
    
    // Set new layout
    contentArea->setLayout(layout);
    
    // Calculate heights
    int collapsedHeight = sizeHint().height() - contentArea->maximumHeight();
    int contentHeight = layout->sizeHint().height();
    
    // Configure animations
    for (int i = 0; i < toggleAnimation->animationCount() - 1; ++i) {
        QPropertyAnimation *animation = qobject_cast<QPropertyAnimation*>(toggleAnimation->animationAt(i));
        if (animation) {
            animation->setDuration(100);
            animation->setStartValue(collapsedHeight);
            animation->setEndValue(collapsedHeight + contentHeight);
        }
    }
    
    QPropertyAnimation *contentAnimation = qobject_cast<QPropertyAnimation*>(toggleAnimation->animationAt(toggleAnimation->animationCount() - 1));
    if (contentAnimation) {
        contentAnimation->setDuration(100);
        contentAnimation->setStartValue(0);
        contentAnimation->setEndValue(contentHeight);
    }
}

void CollapsibleBox::setContentWidget(QWidget *widget)
{
    // Remove existing layout and widgets from content area
    QLayout *existingLayout = contentArea->layout();
    if (existingLayout) {
        delete existingLayout;
    }

    // Remove all existing widgets from content area
    QList<QWidget*> widgets = contentArea->findChildren<QWidget*>();
    for (QWidget *w : widgets) {
        if (w != widget) {
            w->setParent(nullptr);
            delete w;
        }
    }

    // Create a new layout and add the widget to it
    QVBoxLayout *layout = new QVBoxLayout(contentArea);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);

    if (widget) {
        widget->setParent(contentArea);
        layout->addWidget(widget);
    }

    contentArea->setLayout(layout);

    // Calculate heights
    int collapsedHeight = sizeHint().height() - contentArea->maximumHeight();
    int contentHeight = widget ? widget->sizeHint().height() : 0;

    // Configure animations
    for (int i = 0; i < toggleAnimation->animationCount() - 1; ++i) {
        QPropertyAnimation *animation = qobject_cast<QPropertyAnimation*>(toggleAnimation->animationAt(i));
        if (animation) {
            animation->setDuration(100);
            animation->setStartValue(collapsedHeight);
            animation->setEndValue(collapsedHeight + contentHeight);
        }
    }

    QPropertyAnimation *contentAnimation = qobject_cast<QPropertyAnimation*>(toggleAnimation->animationAt(toggleAnimation->animationCount() - 1));
    if (contentAnimation) {
        contentAnimation->setDuration(100);
        contentAnimation->setStartValue(0);
        contentAnimation->setEndValue(contentHeight);
    }
}

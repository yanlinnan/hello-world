#ifndef MYWIDGET_H
#define MYWIDGET_H

#include <QMainWindow>
#include <QDockWidget>
#include <QScrollArea>
#include <QVBoxLayout>
#include <QGridLayout>
#include "CollapsibleBox.h"

class MyWidget : public QMainWindow
{
    Q_OBJECT
public:
    explicit MyWidget(QWidget *parent = nullptr);
    
private:
    void CreateCameraWidget();
    void CreateStageWidget();
    
    QGridLayout *CameraLayout;
    QGridLayout *StageLayout;

    QWidget *CameraWidget;
    QWidget *StageWidget;
};

#endif // MYWIDGET_H

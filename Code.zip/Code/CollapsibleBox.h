#ifndef COLLAPSIBLEBOX_H
#define COLLAPSIBLEBOX_H

#include <QWidget>
#include <QToolButton>
#include <QScrollArea>
#include <QParallelAnimationGroup>
#include <QPropertyAnimation>

class CollapsibleBox : public QWidget
{
    Q_OBJECT
public:
    explicit CollapsibleBox(const QString &title = "", QWidget *parent = nullptr);
    
    void setContentLayout(QLayout *layout);
    void setContentWidget(QWidget *widget);

private slots:
    void onPressed();

private:
    QToolButton *toggleButton;
    QScrollArea *contentArea;
    QParallelAnimationGroup *toggleAnimation;
};

#endif // COLLAPSIBLEBOX_H

#include "MyWidget.h"
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

MyWidget::MyWidget(QWidget *parent)
    : QMainWindow(parent)
{
    // Set central widget
    setCentralWidget(new QWidget());
    
    // Create dock widget
    QDockWidget *dock = new QDockWidget("停靠窗口", this);
    QScrollArea *scroll = new QScrollArea(dock);
    QWidget *content = new QWidget(scroll);
    QVBoxLayout *valy = new QVBoxLayout(content);
    
    scroll->setWidget(content);
    scroll->setWidgetResizable(true);
    dock->setWidget(scroll);
    
    // Add dock widget to main window
    addDockWidget(Qt::LeftDockWidgetArea, dock);
    
    // Create camera and stage widgets
    CreateCameraWidget();
    CreateStageWidget();
    
    // Create collapsible boxes
    CollapsibleBox *camerabox = new CollapsibleBox("相机属性", content);
    CollapsibleBox *stagebox = new CollapsibleBox("位移台属性", content);
    
    // Set content layouts for collapsible boxes
    camerabox->setContentLayout(CameraLayout);
    stagebox->setContentLayout(StageLayout);
    
    // Add widgets to layout
    valy->addWidget(camerabox);
    valy->addWidget(stagebox);
    valy->addStretch();
}

void MyWidget::CreateCameraWidget()
{
    CameraWidget = new QWidget();
    // CameraLayout = new QGridLayout();
    CameraLayout = new QGridLayout(CameraWidget);
    
    QLabel *label1 = new QLabel("曝光时间");
    QLineEdit *edit1 = new QLineEdit("100");
    QPushButton *button1 = new QPushButton("设置");
    QLabel *label2 = new QLabel("增益");
    QLineEdit *edit2 = new QLineEdit("20");
    QPushButton *button2 = new QPushButton("设置");
    
    CameraLayout->addWidget(label1, 0, 0, 1, 1);
    CameraLayout->addWidget(edit1, 0, 1, 1, 1);
    CameraLayout->addWidget(button1, 1, 0, 1, 2);
    CameraLayout->addWidget(label2, 2, 0, 1, 1);
    CameraLayout->addWidget(edit2, 2, 1, 1, 1);
    CameraLayout->addWidget(button2, 3, 0, 1, 2);
}

void MyWidget::CreateStageWidget()
{
    StageWidget = new QWidget();
    // StageLayout = new QGridLayout();
    StageLayout = new QGridLayout(StageWidget);
    
    QLabel *label1 = new QLabel("X位置");
    QLineEdit *edit1 = new QLineEdit("100");
    QPushButton *button1 = new QPushButton("移动");
    QLabel *label2 = new QLabel("Y位置");
    QLineEdit *edit2 = new QLineEdit("100");
    QPushButton *button2 = new QPushButton("移动");
    
    StageLayout->addWidget(label1, 0, 0, 1, 1);
    StageLayout->addWidget(edit1, 0, 1, 1, 1);
    StageLayout->addWidget(button1, 1, 0, 1, 2);
    StageLayout->addWidget(label2, 2, 0, 1, 1);
    StageLayout->addWidget(edit2, 2, 1, 1, 1);
    StageLayout->addWidget(button2, 3, 0, 1, 2);
}

from PyQt5.QtWidgets import QMainWindow, QAction, QApplication
from PyQt5.QtGui import QIcon

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        # 创建一个可选中/取消的Action
        toggle_action = QAction("Toggle Tool", self)
        toggle_action.setCheckable(True)  # 关键设置：使Action可选中
        toggle_action.toggled.connect(self.on_tool_toggled)
        
        # 添加到工具栏
        toolbar = self.addToolBar("Tools")
        toolbar.addAction(toggle_action)
        
        self.show()
    
    def on_tool_toggled(self, checked):
        print(f"工具状态: {'已选中' if checked else '未选中'}")
        # 根据checked状态执行相应操作

if __name__ == "__main__":
    app = QApplication([])
    window = MainWindow()
    app.exec_()
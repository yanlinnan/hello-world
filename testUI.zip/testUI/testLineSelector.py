from matplotlib.widgets import RectangleSelector
import matplotlib.pyplot as plt
import numpy as np

class RobustLineDrawer:
    def __init__(self, ax, on_release_callback=None):
        self.ax = ax
        self.figure = ax.figure
        self.on_release = on_release_callback
        
        # 绘图状态
        self.start_point = None
        self.preview_line = None
        self.final_lines = []
        
        # 连接事件
        self.cid_press = self.figure.canvas.mpl_connect('button_press_event', self.on_press)
        self.cid_move = self.figure.canvas.mpl_connect('motion_notify_event', self.on_move)
        self.cid_release = self.figure.canvas.mpl_connect('button_release_event', self.on_release_event)
    
    def on_press(self, event):
        if event.inaxes != self.ax or event.button != 1:
            return
        self.start_point = (event.xdata, event.ydata)
    
    def on_move(self, event):
        if self.start_point is None or event.inaxes != self.ax:
            return
            
        # 移除旧的预览线
        if self.preview_line is not None:
            self.preview_line.remove()
        
        # 创建新的预览线
        x0, y0 = self.start_point
        self.preview_line, = self.ax.plot(
            [x0, event.xdata], [y0, event.ydata],
            'r--', alpha=0.7, lw=1.5
        )
        self.figure.canvas.draw_idle()
    
    def on_release_event(self, event):
        if self.start_point is None or event.inaxes != self.ax or event.button != 1:
            return
            
        # 移除预览线
        if self.preview_line is not None:
            self.preview_line.remove()
            self.preview_line = None
        
        # 绘制永久线
        x0, y0 = self.start_point
        x1, y1 = event.xdata, event.ydata
        line, = self.ax.plot([x0, x1], [y0, y1], 'r-', lw=2)
        self.final_lines.append(line)
        
        # 调用回调函数
        if self.on_release is not None:
            self.on_release((x0, y0), (x1, y1))
        
        self.start_point = None
        self.figure.canvas.draw_idle()

# 使用示例
fig, ax = plt.subplots(figsize=(8, 6))
ax.set_title("自定义直线绘制工具")
ax.plot(np.random.rand(100), 'b-')  # 示例数据

def line_callback(start, end):
    print(f"绘制了从 {start} 到 {end} 的直线")

drawer = RobustLineDrawer(ax, line_callback)
plt.show()
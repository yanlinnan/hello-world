from PySide6.QtCore import QThread

class LogicThread(QThread):
    def __init__(self):
        super().__init__()

    def run(self):
        while True:
            print(1)
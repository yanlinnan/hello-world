# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainwindow.ui'
##
## Created by: Qt User Interface Compiler version 6.9.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QMainWindow,
    QMenu, QMenuBar, QSizePolicy, QSplitter,
    QStatusBar, QToolBar, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1180, 809)
        self.openFileAction = QAction(MainWindow)
        self.openFileAction.setObjectName(u"openFileAction")
        icon = QIcon(QIcon.fromTheme(QIcon.ThemeIcon.DocumentOpen))
        self.openFileAction.setIcon(icon)
        self.openFileAction.setMenuRole(QAction.MenuRole.ApplicationSpecificRole)
        self.imageRectAction = QAction(MainWindow)
        self.imageRectAction.setObjectName(u"imageRectAction")
        icon1 = QIcon(QIcon.fromTheme(QIcon.ThemeIcon.ImageLoading))
        self.imageRectAction.setIcon(icon1)
        self.imageFlattenAction = QAction(MainWindow)
        self.imageFlattenAction.setObjectName(u"imageFlattenAction")
        self.lineLineAction = QAction(MainWindow)
        self.lineLineAction.setObjectName(u"lineLineAction")
        self.lineFlattenAction = QAction(MainWindow)
        self.lineFlattenAction.setObjectName(u"lineFlattenAction")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.horizontalLayout = QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.splitter = QSplitter(self.centralwidget)
        self.splitter.setObjectName(u"splitter")
        self.splitter.setOrientation(Qt.Orientation.Horizontal)
        self.imageFrame = QFrame(self.splitter)
        self.imageFrame.setObjectName(u"imageFrame")
        self.imageFrame.setFrameShape(QFrame.Shape.StyledPanel)
        self.imageFrame.setFrameShadow(QFrame.Shadow.Raised)
        self.splitter.addWidget(self.imageFrame)
        self.lineFrame = QFrame(self.splitter)
        self.lineFrame.setObjectName(u"lineFrame")
        self.lineFrame.setFrameShape(QFrame.Shape.StyledPanel)
        self.lineFrame.setFrameShadow(QFrame.Shadow.Raised)
        self.splitter.addWidget(self.lineFrame)
        self.toolFrame = QFrame(self.splitter)
        self.toolFrame.setObjectName(u"toolFrame")
        self.toolFrame.setFrameShape(QFrame.Shape.StyledPanel)
        self.toolFrame.setFrameShadow(QFrame.Shadow.Raised)
        self.splitter.addWidget(self.toolFrame)

        self.horizontalLayout.addWidget(self.splitter)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1180, 33))
        self.menu = QMenu(self.menubar)
        self.menu.setObjectName(u"menu")
        self.menu_2 = QMenu(self.menubar)
        self.menu_2.setObjectName(u"menu_2")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.toolBar = QToolBar(MainWindow)
        self.toolBar.setObjectName(u"toolBar")
        MainWindow.addToolBar(Qt.ToolBarArea.TopToolBarArea, self.toolBar)

        self.menubar.addAction(self.menu.menuAction())
        self.menubar.addAction(self.menu_2.menuAction())
        self.menu.addAction(self.openFileAction)
        self.menu_2.addAction(self.imageRectAction)
        self.menu_2.addAction(self.imageFlattenAction)
        self.menu_2.addSeparator()
        self.menu_2.addAction(self.lineLineAction)
        self.menu_2.addAction(self.lineFlattenAction)
        self.toolBar.addAction(self.openFileAction)
        self.toolBar.addSeparator()
        self.toolBar.addAction(self.imageRectAction)
        self.toolBar.addAction(self.imageFlattenAction)
        self.toolBar.addSeparator()
        self.toolBar.addAction(self.lineLineAction)
        self.toolBar.addAction(self.lineFlattenAction)
        self.toolBar.addSeparator()

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.openFileAction.setText(QCoreApplication.translate("MainWindow", u"\u6253\u5f00\u6587\u4ef6", None))
#if QT_CONFIG(shortcut)
        self.openFileAction.setShortcut(QCoreApplication.translate("MainWindow", u"Ctrl+O", None))
#endif // QT_CONFIG(shortcut)
        self.imageRectAction.setText(QCoreApplication.translate("MainWindow", u"\u753b\u6846", None))
#if QT_CONFIG(shortcut)
        self.imageRectAction.setShortcut(QCoreApplication.translate("MainWindow", u"Ctrl+Q", None))
#endif // QT_CONFIG(shortcut)
        self.imageFlattenAction.setText(QCoreApplication.translate("MainWindow", u"\u62c9\u5e73", None))
#if QT_CONFIG(shortcut)
        self.imageFlattenAction.setShortcut(QCoreApplication.translate("MainWindow", u"Ctrl+W", None))
#endif // QT_CONFIG(shortcut)
        self.lineLineAction.setText(QCoreApplication.translate("MainWindow", u"\u753b\u7ebf", None))
#if QT_CONFIG(shortcut)
        self.lineLineAction.setShortcut(QCoreApplication.translate("MainWindow", u"Ctrl+E", None))
#endif // QT_CONFIG(shortcut)
        self.lineFlattenAction.setText(QCoreApplication.translate("MainWindow", u"\u62c9\u5e73", None))
#if QT_CONFIG(shortcut)
        self.lineFlattenAction.setShortcut(QCoreApplication.translate("MainWindow", u"Ctrl+R", None))
#endif // QT_CONFIG(shortcut)
        self.menu.setTitle(QCoreApplication.translate("MainWindow", u"\u6587\u4ef6", None))
        self.menu_2.setTitle(QCoreApplication.translate("MainWindow", u"\u529f\u80fd", None))
        self.toolBar.setWindowTitle(QCoreApplication.translate("MainWindow", u"toolBar", None))
    # retranslateUi


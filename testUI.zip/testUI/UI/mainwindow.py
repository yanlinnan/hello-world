# 主窗口
import sys
from PySide6.QtWidgets import QMainWindow,QApplication,QHBoxLayout
# from mainwindow_ui import Ui_MainWindow
from UI.mainwindow_ui import Ui_MainWindow

from UI.imagewindow import ImageWindow
from UI.linewindow import LineWindow
from UI.toolbox import toolbox

class mainwindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.retranslateUi(self)
        self.initui()
        self.initevent()


    def initui(self):
        self.toolbox = toolbox()
        layout = QHBoxLayout()
        layout.addWidget(self.toolbox)
        self.toolFrame.setLayout(layout)

        self.imageWindow = ImageWindow()
        imagelayout = QHBoxLayout()
        imagelayout.addWidget(self.imageWindow)
        self.imageFrame.setLayout(imagelayout)

        self.lineWindow = LineWindow()
        linelayout = QHBoxLayout()
        linelayout.addWidget(self.lineWindow)
        self.lineFrame.setLayout(linelayout)

    def initevent(self):
        1

if __name__== '__main__':
    app = QApplication([])
    window = mainwindow()
    window.show()
    sys.exit(app.exec())
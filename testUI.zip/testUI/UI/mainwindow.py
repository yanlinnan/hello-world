# 主窗口
import cv2
import sys
from PySide6.QtWidgets import QMainWindow,QApplication,QHBoxLayout,QFileDialog
# from mainwindow_ui import Ui_MainWindow
from UI.mainwindow_ui import Ui_MainWindow

from UI.imagewindow import ImageWindow
from UI.linewindow import LineWindow
from UI.toolbox import toolbox

class mainwindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.retranslateUi(self)
        self.initui()
        self.initevent()


    def initui(self):
        self.imageRectAction.setCheckable(True)
        self.lineLineAction.setCheckable(True)

        self.toolbox = toolbox()
        layout = QHBoxLayout()
        layout.addWidget(self.toolbox)
        self.toolFrame.setLayout(layout)

        self.imageWindow = ImageWindow()
        imagelayout = QHBoxLayout()
        imagelayout.addWidget(self.imageWindow)
        self.imageFrame.setLayout(imagelayout)

        self.lineWindow = LineWindow()
        linelayout = QHBoxLayout()
        linelayout.addWidget(self.lineWindow)
        self.lineFrame.setLayout(linelayout)

    def initevent(self):
        self.openFileAction.triggered.connect(self.on_openfile_clicked)
        self.imageRectAction.triggered.connect(self.on_imagerect_clicked)
        self.imageFlattenAction.triggered.connect(self.on_imageflatten_clicked)
        self.lineLineAction.triggered.connect(self.on_lineline_clicked)
        self.lineFlattenAction.triggered.connect(self.on_lineflatten_clicked)

    def on_openfile_clicked(self):
        print('act')
        path, _ = QFileDialog.getOpenFileName()
        if path:
            print(path)
            image = cv2.imread(path,cv2.IMREAD_GRAYSCALE)
            self.imageWindow.draw_image(image)

    def on_imagerect_clicked(self):
        if self.imageRectAction.isChecked():
            self.imageWindow.enable_rect_selector(True)
        else:
            self.imageWindow.enable_rect_selector(False)

    def on_imageflatten_clicked(self):
        1

    def on_lineline_clicked(self):
        if self.lineLineAction.isChecked():
            self.imageWindow.enable_line_selectot(True)
        else:
            self.imageWindow.enable_line_selectot(False)

    def on_lineflatten_clicked(self):
        1

if __name__== '__main__':
    app = QApplication([])
    window = mainwindow()
    window.show()
    sys.exit(app.exec())
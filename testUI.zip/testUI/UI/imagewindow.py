# 图像显示窗口
import sys
from PySide6.QtWidgets import QWidget, QApplication,QVBoxLayout
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.widgets import RectangleSelector
from matplotlib.widgets import LassoSelector

class ImageWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initui()
        self.initevent()

        self.rect_selector_list = []
        self.rect_selector_active_list = [] # 此数组应始终表示对应rectselector的活动状态，否则会产生乱七八糟的bug
        self.rect_selector_xy_list = []
        self.draw_or_move = True
        self.recting = False
        self.curent_rect_selector = None

        self.lineing = False

    def initui(self):
        self.fig = Figure()
        self.canvas = FigureCanvas(self.fig)
        self.toolbar = NavigationToolbar(self.canvas)

        layout = QVBoxLayout()
        layout.addWidget(self.toolbar)
        layout.addWidget(self.canvas)
        self.setLayout(layout)

        self.fig.clear()
        self.ax_exist = False

    def initevent(self):
        self.fig.canvas.mpl_connect('button_press_event', self.on_left_press_clicked)
        self.fig.canvas.mpl_connect('button_release_event', self.on_left_release_clicked)
        self.fig.canvas.mpl_connect('key_release_event',self.on_key_release_clicked)

    def on_left_press_clicked(self,event):
        # 判断按下的位置是否是已经画框的边界，如果是，则启动对应的rectselector，关闭当前rectselector，并设置标志位保证on_select不创建新的rectselector
        # 如果不是，则关闭所有rectselector，启动当前rectselector设置标志位保证on_select创建新的rectselector
        if self.recting and event.inaxes and event.button == 1:
            x = event.xdata
            y = event.ydata
            for i in range(len(self.rect_selector_xy_list)):
                if self.xy_in_rect(x,y,self.rect_selector_xy_list[i]):
                    #  关闭当前框
                    self.curent_rect_selector.set_active(False)
                    self.rect_selector_active_list[len(self.rect_selector_active_list) - 1] = False                    
                    # 启动选中的框
                    self.rect_selector_list[i].set_active(True)
                    self.rect_selector_active_list[i] = True
                    # 设置标志位，这次不绘制新框，只移动旧框
                    self.draw_or_move= False
                    return
            # 循环结束表示没有点到已经存在的矩形框,关闭除了最后一个rectselector外的所有rectselector
            self.close_all_rectselector()
            self.curent_rect_selector.set_active(True)
            self.rect_selector_active_list[len(self.rect_selector_active_list) - 1] = True
            self.draw_or_move = True

    def on_left_release_clicked(self,event):
        # 画框时槽函数触发顺序是，先出发鼠标释放槽函数，再触发rectselector指定的槽函数on_select
        if self.recting and event.inaxes and event.button == 1:
            x = event.xdata
            y = event.ydata

    def on_key_release_clicked(self,event):
        print(event) # 按键无效
        if event.key == 'delete' or event.key == 'backspace':
            print('del')

    def xy_in_rect(self,x,y,rect):
        xmin,xmax,ymin,ymax = rect
        # # 依次判断左边界，右边界，上边界，下边界
        # o = 5 # 允许偏移误差
        # if (x > xmin-o and x < xmin+o and y > ymin-o and y < ymax+o) or \
        #    (x > xmax-o and x < xmax+o and y > ymin-o and y < ymax+o) or \
        #    (y > ymin-o and y < ymin+o and x > xmin-o and x < xmax+o) or \
        #    (y > ymax-o and y < ymax+o and x > xmin-o and x < xmax+o):
        #     # print('选中',x,y,rect)
        #     return True
        # else:
        #     # print('非选中',x,y,rect)
        #     return False

        # rectselector只判断9个点，如果在这个函数里判断整个边界会导致选中9个点之外的点时重新绘制矩形
        o = 7 # 允许偏移误差
        xmid = (xmax + xmin) / 2
        ymid = (ymax + ymin) / 2
        for xx in [xmin,xmid,xmax]:
            for yy in [ymin,ymid,ymax]:
                if abs(x - xx) < o and abs(y - yy) < o:
                    print('选中',x,y,[xmin,xmid,xmax],[ymin,ymid,ymax])
                    return True
        print('非选中',x,y,[xmin,xmid,xmax],[ymin,ymid,ymax])
        return False

    def close_all_rectselector(self):
        for i in range(len(self.rect_selector_list)):
            self.rect_selector_list[i].set_active(False)
            self.rect_selector_active_list[i] = False

    def draw_image(self,image):
        # TODO:传入图像后应该清空rectselector相关的数组
        if not self.ax_exist:
            self.ax = self.fig.add_subplot(1,1,1)
            # self.create_rectangleSelector()
        self.ax.clear()
        self.ax.imshow(image)
        self.canvas.draw()

    def create_rectangleSelector(self):
        rect_selector = RectangleSelector(
            self.ax, self.on_select,
            useblit=True,                   # 是否使用blitting提高性能
            button=[1],                     # 1:左键，2:中键，3:右键
            minspanx=5, minspany=5,
            spancoords='pixels',            # 'pixels':以像素作为最小单位 ,'data':以坐标作为最小单位
            interactive=True,                # 选择后是否可以拖动调整矩形
            # 矩形样式
            props=dict(edgecolor='red',alpha=1,fill=False,linewidth=2),
        )
        self.curent_rect_selector = rect_selector
        self.rect_selector_list.append(rect_selector)
        self.rect_selector_active_list.append(True)

    def on_select(self, eclick, erelease):
        x1, y1 = eclick.xdata, eclick.ydata
        x2, y2 = erelease.xdata, erelease.ydata
        # print(f"选择的区域: x=[{x1:.2f}, {x2:.2f}], y=[{y1:.2f}, {y2:.2f}]")
        # print(len(self.rect_selector_list))        
        if self.draw_or_move:
            # print('绘制')
            # 框选完成，保存坐标并关闭
            self.rect_selector_xy_list.append([x1,x2,y1,y2])
            self.rect_selector_active_list[len(self.rect_selector_active_list) - 1] = False
            self.curent_rect_selector.set_active(False)

            # 框选完成，需要保持旧的rect显示并创建新的rectselector
            self.curent_rect_selector.extents = self.rect_selector_xy_list[len(self.rect_selector_xy_list)-1]
            self.create_rectangleSelector()
        else:
            # 移动，确定当前活动的rectselecter的序号，更新坐标并固定其位置(取消活动并设置extents(初始位置))
            # 目前在鼠标按下之后启动对应rectselector也可以使rectselector获取鼠标位置，后续如果有问题可以改成在鼠标按下之前判断启动
            # print('移动')
            for i in range(len(self.rect_selector_active_list)):
                if self.rect_selector_active_list[i] == True:
                    self.rect_selector_xy_list[i] = [x1,x2,y1,y2]
                    self.rect_selector_list[i].set_active(False)
                    self.rect_selector_active_list[i] = False
                    self.rect_selector_list[i].extents = [x1,x2,y1,y2]

    def enable_rect_selector(self, re):
        # self.rect_selector.set_active(re) # True启用，False禁用
        self.recting = re
        if re:
            if len(self.rect_selector_list) == 0:
                self.create_rectangleSelector()
            else:
                i = len(self.rect_selector_list) - 1
                self.rect_selector_list[i].set_active(True)
                self.rect_selector_active_list[i] = True
        else:
            self.close_all_rectselector()

    # 下面的方法可以绘制出任意曲线而不是直线
    def enable_line_selectot(self, re):
        self.lineing = re
        self.create_lineSelector()
        
    def create_lineSelector(self):
        self.lasso = LassoSelector(self.ax, self.on_select_line)

    def on_select_line(self, verts):
        # verts 包含套索路径的顶点
        print("选择的路径:", verts)

if __name__ == '__main__':
    app = QApplication([])
    w = ImageWindow()
    w.show()
    sys.exit(app.exec())
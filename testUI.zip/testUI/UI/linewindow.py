# 曲线显示窗口
import sys
from PySide6.QtWidgets import QWidget, QApplication,QVBoxLayout
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar

class LineWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initui()

    def initui(self):
        self.fig = Figure()
        self.canvas = FigureCanvas(self.fig)
        self.toolbar = NavigationToolbar(self.canvas)

        layout = QVBoxLayout()
        layout.addWidget(self.toolbar)
        layout.addWidget(self.canvas)
        self.setLayout(layout)

if __name__ == '__main__':
    app = QApplication([])
    w = LineWindow()
    w.show()
    sys.exit(app.exec())
# 工具窗口
import sys
from PySide6.QtWidgets import QMainWindow,QApplication,QFrame
from UI.toolbox_ui import Ui_Frame

class toolbox(QFrame, Ui_Frame):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.retranslateUi(self)

    def load_ui(self):
        1

if __name__== '__main__':
    app = QApplication([])
    window = toolbox()
    window.show()
    sys.exit(app.exec())
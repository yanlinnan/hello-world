# 工具窗口
import sys
from PySide6.QtWidgets import QMainWindow,QApplication,QFrame
from UI.toolbox_ui import Ui_Frame

class toolbox(QFrame, Ui_Frame):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.retranslateUi(self)
        self.initevent()

    def initevent(self):
        self.openBtn.clicked.connect(self.on_openfile_clicked)

    def on_openfile_clicked(self):
        print('btn')

if __name__== '__main__':
    app = QApplication([])
    window = toolbox()
    window.show()
    sys.exit(app.exec())
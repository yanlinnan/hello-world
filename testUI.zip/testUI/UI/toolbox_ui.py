# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'toolbox.ui'
##
## Created by: Qt User Interface Compiler version 6.9.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QFrame, QLabel,
    QLineEdit, QPushButton, QSizePolicy, QVBoxLayout,
    QWidget)

class Ui_Frame(object):
    def setupUi(self, Frame):
        if not Frame.objectName():
            Frame.setObjectName(u"Frame")
        Frame.resize(172, 538)
        self.verticalLayout = QVBoxLayout(Frame)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.fileLineEdit = QLineEdit(Frame)
        self.fileLineEdit.setObjectName(u"fileLineEdit")

        self.verticalLayout.addWidget(self.fileLineEdit)

        self.openBtn = QPushButton(Frame)
        self.openBtn.setObjectName(u"openBtn")

        self.verticalLayout.addWidget(self.openBtn)

        self.imageRectBtn = QPushButton(Frame)
        self.imageRectBtn.setObjectName(u"imageRectBtn")

        self.verticalLayout.addWidget(self.imageRectBtn)

        self.imageFlattenBtn = QPushButton(Frame)
        self.imageFlattenBtn.setObjectName(u"imageFlattenBtn")

        self.verticalLayout.addWidget(self.imageFlattenBtn)

        self.lineLineBtn = QPushButton(Frame)
        self.lineLineBtn.setObjectName(u"lineLineBtn")

        self.verticalLayout.addWidget(self.lineLineBtn)

        self.comboBox = QComboBox(Frame)
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.setObjectName(u"comboBox")

        self.verticalLayout.addWidget(self.comboBox)

        self.lineFlattenBtn = QPushButton(Frame)
        self.lineFlattenBtn.setObjectName(u"lineFlattenBtn")

        self.verticalLayout.addWidget(self.lineFlattenBtn)

        self.label = QLabel(Frame)
        self.label.setObjectName(u"label")

        self.verticalLayout.addWidget(self.label)


        self.retranslateUi(Frame)

        QMetaObject.connectSlotsByName(Frame)
    # setupUi

    def retranslateUi(self, Frame):
        Frame.setWindowTitle(QCoreApplication.translate("Frame", u"Frame", None))
        self.openBtn.setText(QCoreApplication.translate("Frame", u"\u6253\u5f00\u6587\u4ef6", None))
        self.imageRectBtn.setText(QCoreApplication.translate("Frame", u"\u753b\u6846", None))
        self.imageFlattenBtn.setText(QCoreApplication.translate("Frame", u"\u62c9\u5e73", None))
        self.lineLineBtn.setText(QCoreApplication.translate("Frame", u"\u753b\u7ebf", None))
        self.comboBox.setItemText(0, QCoreApplication.translate("Frame", u"\u4e00\u9636", None))
        self.comboBox.setItemText(1, QCoreApplication.translate("Frame", u"\u4e8c\u9636", None))

        self.lineFlattenBtn.setText(QCoreApplication.translate("Frame", u"\u62c9\u5e73", None))
        self.label.setText("")
    # retranslateUi


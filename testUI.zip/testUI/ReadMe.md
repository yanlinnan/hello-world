## 生成ui
pyside6-uic.exe ./UI/mainwindow.ui -o ./UI/mainwindow_ui.py
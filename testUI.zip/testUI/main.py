import sys
from PySide6.QtWidgets import QApplication
from UI.mainwindow import mainwindow

if __name__== '__main__':
    app = QApplication([])
    window = mainwindow()
    window.show()
    sys.exit(app.exec())